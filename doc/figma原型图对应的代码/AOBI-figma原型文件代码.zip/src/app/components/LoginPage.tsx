import { useState } from 'react';
import { useNavigate } from 'react-router';
import { User, Lock, Eye, EyeOff } from 'lucide-react';

export function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const handleLogin = () => {
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="w-[500px] bg-white rounded-2xl shadow-2xl p-12">
        {/* Logo and Title */}
        <div className="flex flex-col items-center mb-8">
          <div className="flex items-center gap-3 mb-3">
            <div className="flex gap-1">
              <div className="w-2 h-8 bg-blue-400 rounded"></div>
              <div className="w-2 h-8 bg-blue-500 rounded"></div>
              <div className="w-2 h-8 bg-blue-600 rounded"></div>
            </div>
            <h1 className="text-4xl font-bold text-gray-800">鱼智能 BI</h1>
          </div>
          <p className="text-blue-500 text-sm">编程导航知识星球的原创项目</p>
        </div>

        {/* Login Form */}
        <div className="mb-8">
          <div className="text-center mb-6">
            <h2 className="text-blue-500 text-lg font-medium pb-2 border-b-2 border-blue-500 inline-block">
              账户密码登录
            </h2>
          </div>

          <div className="space-y-5">
            {/* Username Input */}
            <div className="relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                <User size={20} />
              </div>
              <input
                type="text"
                placeholder="yupi"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full pl-12 pr-10 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
              />
              {username && (
                <button
                  onClick={() => setUsername('')}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  <span className="text-lg">×</span>
                </button>
              )}
            </div>

            {/* Password Input */}
            <div className="relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                <Lock size={20} />
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder="12345678"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-12 pr-10 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
              />
              <button
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>

          {/* Register Link */}
          <div className="mt-4">
            <button
              onClick={() => navigate('/register')}
              className="text-blue-500 hover:text-blue-600 text-sm"
            >
              注册
            </button>
          </div>
        </div>

        {/* Login Button */}
        <button
          onClick={handleLogin}
          className="w-full bg-blue-500 hover:bg-blue-600 text-white py-3 rounded-lg font-medium transition-colors"
        >
          登录
        </button>

        {/* Footer */}
        <div className="mt-6 text-right">
          <p className="text-sm text-gray-500">
            编程导航
            <br />
            <span className="text-blue-500">codefather.cn</span>
          </p>
        </div>
      </div>
    </div>
  );
}
