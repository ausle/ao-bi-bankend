import { useState } from 'react';
import { User, Mail, Calendar, Edit2, Save } from 'lucide-react';

export function ProfilePage() {
  const [isEditing, setIsEditing] = useState(false);
  const [username, setUsername] = useState('Yupi');
  const [email, setEmail] = useState('yupi@example.com');
  const [bio, setBio] = useState('编程导航知识星球成员，热爱数据分析');

  const handleSave = () => {
    setIsEditing(false);
    alert('个人信息已保存');
  };

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-8">个人中心</h1>

      <div className="max-w-3xl">
        {/* Profile Header */}
        <div className="bg-white rounded-lg p-8 shadow-sm mb-6">
          <div className="flex items-start gap-6">
            {/* Avatar */}
            <div className="w-24 h-24 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white text-3xl font-bold">
              YP
            </div>

            {/* User Info */}
            <div className="flex-1">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold">{username}</h2>
                {!isEditing ? (
                  <button
                    onClick={() => setIsEditing(true)}
                    className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                  >
                    <Edit2 size={18} />
                    编辑资料
                  </button>
                ) : (
                  <button
                    onClick={handleSave}
                    className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                  >
                    <Save size={18} />
                    保存
                  </button>
                )}
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-2 text-gray-600">
                  <Mail size={18} />
                  {isEditing ? (
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="flex-1 px-3 py-1 border border-gray-300 rounded focus:outline-none focus:border-blue-500"
                    />
                  ) : (
                    <span>{email}</span>
                  )}
                </div>

                <div className="flex items-center gap-2 text-gray-600">
                  <Calendar size={18} />
                  <span>加入时间：2023-01-15</span>
                </div>
              </div>
            </div>
          </div>

          {/* Bio */}
          <div className="mt-6 pt-6 border-t border-gray-200">
            <label className="block text-sm font-medium mb-2 text-gray-700">
              个人简介
            </label>
            {isEditing ? (
              <textarea
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg resize-none focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                rows={3}
              />
            ) : (
              <p className="text-gray-600">{bio}</p>
            )}
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-lg p-6 shadow-sm text-center">
            <div className="text-3xl font-bold text-blue-500 mb-2">12</div>
            <div className="text-sm text-gray-600">创建的图表</div>
          </div>
          <div className="bg-white rounded-lg p-6 shadow-sm text-center">
            <div className="text-3xl font-bold text-green-500 mb-2">8</div>
            <div className="text-sm text-gray-600">分析任务</div>
          </div>
          <div className="bg-white rounded-lg p-6 shadow-sm text-center">
            <div className="text-3xl font-bold text-purple-500 mb-2">45</div>
            <div className="text-sm text-gray-600">使用天数</div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-lg p-6 shadow-sm">
          <h3 className="font-bold mb-4">最近活动</h3>
          <div className="space-y-3">
            <div className="flex items-center gap-3 pb-3 border-b border-gray-100">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm">创建了新图表：网站用户增长分析</p>
                <p className="text-xs text-gray-500">2026-04-22 15:30</p>
              </div>
            </div>
            <div className="flex items-center gap-3 pb-3 border-b border-gray-100">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm">完成了数据分析：销售趋势预测</p>
                <p className="text-xs text-gray-500">2026-04-21 10:15</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm">上传了数据文件：sales_data.csv</p>
                <p className="text-xs text-gray-500">2026-04-20 14:20</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
