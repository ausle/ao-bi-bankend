export function ChartsPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-8">我的图表</h1>

      <div className="bg-white rounded-lg p-12 shadow-sm text-center">
        <p className="text-gray-500">暂无图表数据</p>
        <p className="text-sm text-gray-400 mt-2">请先在智能分析页面创建图表</p>
      </div>
    </div>
  );
}
