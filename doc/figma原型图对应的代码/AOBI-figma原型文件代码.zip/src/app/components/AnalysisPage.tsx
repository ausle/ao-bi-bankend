import { useState } from 'react';
import { Upload } from 'lucide-react';

export function AnalysisPage() {
  const [analysisGoal, setAnalysisGoal] = useState('');
  const [chartName, setChartName] = useState('');
  const [chartType, setChartType] = useState('');
  const [fileName, setFileName] = useState('');

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
    }
  };

  const handleSubmit = () => {
    console.log('提交表单');
  };

  const handleReset = () => {
    setAnalysisGoal('');
    setChartName('');
    setChartType('');
    setFileName('');
  };

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-8">智能分析</h1>

      <div className="grid grid-cols-2 gap-8">
        {/* Left Column - Form */}
        <div className="bg-white rounded-lg p-6 shadow-sm">
          <div className="space-y-6">
            {/* Analysis Goal */}
            <div>
              <label className="block text-sm mb-2">
                <span className="text-red-500">* </span>
                分析目标：
              </label>
              <textarea
                value={analysisGoal}
                onChange={(e) => setAnalysisGoal(e.target.value)}
                placeholder="请输入你的分析诉求，比如：分析网站增长情况"
                className="w-full h-24 px-4 py-2 border border-gray-300 rounded-lg resize-none focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
              />
            </div>

            {/* Chart Name */}
            <div>
              <label className="block text-sm mb-2">图表名称：</label>
              <input
                type="text"
                value={chartName}
                onChange={(e) => setChartName(e.target.value)}
                placeholder="请输入图表名称"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
              />
            </div>

            {/* Chart Type */}
            <div>
              <label className="block text-sm mb-2">图表类型：</label>
              <select
                value={chartType}
                onChange={(e) => setChartType(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 bg-white"
              >
                <option value=""></option>
                <option value="line">折线图</option>
                <option value="bar">柱状图</option>
                <option value="pie">饼图</option>
                <option value="scatter">散点图</option>
              </select>
            </div>

            {/* File Upload */}
            <div>
              <label className="block text-sm mb-2">图纸数据：</label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                <input
                  type="file"
                  id="file-upload"
                  accept=".csv"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <label
                  htmlFor="file-upload"
                  className="cursor-pointer flex flex-col items-center gap-2"
                >
                  <Upload className="text-blue-500" size={32} />
                  <span className="text-blue-500">上传 CSV 文件</span>
                  {fileName && (
                    <span className="text-sm text-gray-600 mt-2">{fileName}</span>
                  )}
                </label>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4 pt-4">
              <button
                onClick={handleSubmit}
                className="px-8 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
              >
                提交
              </button>
              <button
                onClick={handleReset}
                className="px-8 py-2 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg transition-colors"
              >
                重置
              </button>
            </div>
          </div>
        </div>

        {/* Right Column - Results */}
        <div className="space-y-6">
          {/* Analysis Conclusion */}
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h2 className="font-bold mb-3">分析结论</h2>
            <p className="text-sm text-gray-500">请先在左侧进行提交</p>
          </div>

          {/* Visualization */}
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h2 className="font-bold mb-3">可视化图表</h2>
            <p className="text-sm text-gray-500">请先在左侧进行提交</p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="mt-8 text-center text-sm text-gray-500">
        <p>鱼智能图 鱼智能BI © 2023 编程导航知识星球出品</p>
        <p className="text-blue-500 mt-1">编程导航 codefather.cn</p>
      </div>
    </div>
  );
}
