import { createBrowserRouter, Navigate } from 'react-router';
import { LoginPage } from './components/LoginPage';
import { RegisterPage } from './components/RegisterPage';
import { DashboardLayout } from './components/DashboardLayout';
import { AnalysisPage } from './components/AnalysisPage';
import { ChartsPage } from './components/ChartsPage';
import { ProfilePage } from './components/ProfilePage';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <Navigate to="/login" replace />,
  },
  {
    path: '/login',
    Component: LoginPage,
  },
  {
    path: '/register',
    Component: RegisterPage,
  },
  {
    path: '/dashboard',
    Component: DashboardLayout,
    children: [
      {
        index: true,
        element: <Navigate to="/dashboard/analysis" replace />,
      },
      {
        path: 'analysis',
        Component: AnalysisPage,
      },
      {
        path: 'charts',
        Component: ChartsPage,
      },
      {
        path: 'profile',
        Component: ProfilePage,
      },
    ],
  },
]);
